#include <stdio.h>
#include "../headers/header.h"

int make_numb_index_two(int num)
{
	
}