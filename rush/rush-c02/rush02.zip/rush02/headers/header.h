#ifndef HEADER_H
#define HEADER_H
#include <unistd.h>
#include <stdio.h>
int	check_pos_neg(char *str);
int	ft_atoi(char *str);
int make_numb_index(int num);
int	make_round_numbers(int num, int index);
#endif